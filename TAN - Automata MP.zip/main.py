# Tan, Lance Griffin L.
# CSC615M - Machine Project

from gui import GUI

gui = GUI()
gui.mainloop()